class Duck:
    def quack(self):
        print("Quack!")

    def fly(self):
        print("I'm flying!")

class Person:
    def quack(self):
        print("I'm pretending to be a duck!")

    def fly(self):
        print("I'm pretending to fly like a duck!")

def perform_duck_actions(duck):
    duck.quack()
    duck.fly()

# Both Duck and Person can be passed to perform_duck_actions
duck = Duck()
person = Person()

perform_duck_actions(duck)   # Quack! I'm flying!
perform_duck_actions(person) # I'm pretending to be a duck! I'm pretending to fly like a duck!
