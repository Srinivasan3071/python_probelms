from abc import ABC, abstractmethod

class Switchable(ABC):
    @abstractmethod
    def turn_on(self):
        pass

class LightBulb(Switchable):
    def turn_on(self):
        print("Light bulb turned on")

class Fan(Switchable):
    def turn_on(self):
        print("Fan turned on")

class Switch:
    def __init__(self, device: Switchable):
        self.device = device

    def operate(self):
        self.device.turn_on()


light_bulb = LightBulb()
fan = Fan()

light_switch = Switch(light_bulb)
fan_switch = Switch(fan)

light_switch.operate()  # Output: Light bulb turned on
fan_switch.operate()    # Output: Fan turned on
