def aa(func):
    def wrapper():
        print("k")
        func()
        print("j")
    return wrapper
@aa
def b():
    print("hi")
b()    