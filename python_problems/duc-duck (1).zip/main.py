class python:
    def execute(self):
        print("k")
class java:
    def execute(self):
        print("j")
class lap:
    def code(self,ide):
        ide.execute()
ide=java()#has a method to execute which class object it is..
lap1=lap()
lap1.code(ide)# Pass the Java instance to the code method