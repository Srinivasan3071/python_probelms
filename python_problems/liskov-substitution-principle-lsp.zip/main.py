class Bird:
    def fly(self):
        print("Flying")

class Sparrow(Bird):
    pass

class Ostrich(Bird):
    def fly(self):
        raise NotImplementedError("Ostriches cannot fly")

def make_bird_fly(bird: Bird):
    bird.fly()

sparrow = Sparrow()
ostrich = Ostrich()

make_bird_fly(sparrow)  # Works
make_bird_fly(ostrich)  # Raises NotImplementedError
