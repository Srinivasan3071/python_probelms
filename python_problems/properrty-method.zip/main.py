class Rectangle:
    def __init__(self, width, height):
        self._width = width
        self._height = height

    @property
    def area(self):
        return self._width * self._height

    @area.setter
    def area(self, value):
        self._width = value / self._height

rect = Rectangle(4, 5)
print(rect.area)  # Output: 20

# After setting a new area
rect.area = 30
print(rect._width)  # Output: 6
print(rect.area)    # Output: 30
