class a:
  def __init__(self, name,lname):
    self.firstname = name
    self.lastname = lname

  def printname(self):
    print(self.firstname, self.lastname)


x = a("mad", "max")
x.printname()
