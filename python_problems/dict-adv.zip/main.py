# Creating a dictionary
my_dict = {'a': 1, 'b': 2, 'c': 3}

# Accessing values
print(my_dict['a'])  # Output: 1

# Modifying values
my_dict['b'] = 10
print(my_dict)

# Adding key-value pairs
my_dict['d'] = 4
print(my_dict)

# Removing key-value pairs
del my_dict['c']
print(my_dict)

# Iterating over keys and values
for key, value in my_dict.items():
    print(f'{key}: {value}')
# Output:
# a: 1
# b: 10
# d: 4

# Dictionary comprehension
squared_values = {key: value**2 for key, value in my_dict.items()}
print(squared_values)  # Output: {'a': 1, 'b': 100, 'd': 16}
