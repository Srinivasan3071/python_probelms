class Grandparent:
    def method(self):
        print("Grandparent method")

class Parent(Grandparent):
    pass

class Child(Parent):
    pass

c = Child()
c.method()  # Output: Grandparent method
