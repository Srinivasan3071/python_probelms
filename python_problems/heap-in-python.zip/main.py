import heapq

# Create a heap
heap = [3, 1, 4, 1, 5, 9]
heapq.heapify(heap)  # Transform list into a heap
print(heap)

# Push new item onto the heap
heapq.heappush(heap, 2)  # Add 2 to the heap
print(heap)
# Pop the smallest item
smallest = heapq.heappop(heap)  # 1 (the smallest item)
print(heap)