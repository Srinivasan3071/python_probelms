from functools import wraps

def log_execution(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        print(f"Executing {func.__name__} with arguments {args} and {kwargs}")
        result = func(*args, **kwargs)
        print(f"Finished executing {func.__name__} with result {result}")
        return result
    return wrapper

@log_execution
def add(a, b):
    return a + b

@log_execution
def greet(name, greeting="Hello"):
    return f"{greeting}, {name}!"

print(add(2, 3))
print(greet("Alice", greeting="Hi"))
