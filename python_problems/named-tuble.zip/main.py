from collections import namedtuple

# Define a named tuple
Point = namedtuple('Point', ['x', 'y'])

# Create an instance of Point
p = Point(10, 20)

# Access fields by name
print(p.x)  # 10
print(p.y)  # 20
