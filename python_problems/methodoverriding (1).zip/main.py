class Animal:
    def speak(self):
        return "Some sound"

class Dog(Animal):
    def speak(self):
        return "Woof!"

animal = Animal()
dog = Dog()

print(animal.speak())  # Outputs: Some sound
print(dog.speak())     # Outputs: Woof!
