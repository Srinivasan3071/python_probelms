class Math:
    @staticmethod
    def add(x, y):
        return x + y

print(Math.add(5, 3))  # Output: 8
