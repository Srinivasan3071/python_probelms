with open('hello.txt','w') as file:
    file.write("hello")
try:
    file=open('hello.txt','w')
    file.write("hello")
except:
    print("errror")
finally:
    file.close()