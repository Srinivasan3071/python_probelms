class Report:
    def __init__(self, data):
        self.data = data

    def generate_report(self):
        return f"Report Data: {self.data}"

class ReportPrinter:
    def print_report(self, report):
        print(report.generate_report())

data = {"name": "max", "age": 30}
report = Report(data)
printer = ReportPrinter()
printer.print_report(report)
