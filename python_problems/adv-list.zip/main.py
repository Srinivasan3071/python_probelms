# Creating a list
my_list = [1, 2, 3, 4, 5]

# Accessing elements
print(my_list[0])  # Output: 1

# Modifying elements
my_list[1] = 10
print(my_list)

# Adding elements
my_list.append(6)
print(my_list)

# Removing elements
my_list.remove(4)
print(my_list)

# List comprehension
squared = [x**2 for x in my_list] 
print(squared) 
