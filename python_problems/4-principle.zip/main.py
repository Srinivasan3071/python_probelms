from abc import ABC, abstractmethod

class Workable(ABC):
    @abstractmethod
    def work(self):
        pass

class Eatable(ABC):
    @abstractmethod
    def eat(self):
        pass

class Worker(Workable, Eatable):
    def work(self):
        print("Working")

    def eat(self):
        print("Eating")

class Manager(Workable):
    def work(self):
        print("Managing")

# Create instances
worker = Worker()
manager = Manager()

# Call the methods
worker.work()  # Output: Working
worker.eat()   # Output: Eating
manager.work()  # Output: Managing
