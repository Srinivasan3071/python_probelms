class MyContextManager:
    def __enter__(self):
        print("Entering the context")
        return self 

    def __exit__(self, name, mode, traceback):
        print("Exiting the context")
      

with MyContextManager() as manager:
    print("Inside the context")
