def print_args(*args):
    for arg in args:
        print(arg)

print_args(1, 2, 3)
