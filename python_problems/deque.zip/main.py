from collections import deque

# Create a deque
dq = deque([1, 2, 3])

# Append to the right
dq.append(4)  # deque([1, 2, 3, 4])
print(dq)

# Append to the left
dq.appendleft(0)  # deque([0, 1, 2, 3, 4])
print(dq)

# Pop from the right
dq.pop()  # deque([0, 1, 2, 3])
print(dq)

# Pop from the left
dq.popleft()  # deque([1, 2, 3])
print(dq)
