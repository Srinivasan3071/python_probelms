class Grandparent:
    def method(self):
        print("Grandparent method")

class Parent1(Grandparent):
    pass

class Parent2(Grandparent):
    pass

class Child(Parent1, Parent2):
    pass

c = Child()
c.method()  # Output: Grandparent method
