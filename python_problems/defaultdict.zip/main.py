from collections import defaultdict

# Create a defaultdict with int as default factory
dd = defaultdict(int)

# Increment counts
dd['apple'] += 1
dd['banana'] += 2

# Access missing key returns default value
print(dd['apple'])  # 1
print(dd['banana'])  # 2
print(dd['cherry'])  # 0 (default value)
