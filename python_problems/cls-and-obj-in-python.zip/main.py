class a:
  def __init__(self, name, age):
    self.name = name
    self.age = age

b = a("max", 20)

print(b.name)
print(b.age)
