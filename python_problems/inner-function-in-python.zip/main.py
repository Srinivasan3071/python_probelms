def outer_function(x):
    print(f"Outer function: x = {x}")

    def inner_function(y):
        print(f"Inner function: x = {x}, y = {y}")
        return x + y

    result = inner_function(5)
    return result

result = outer_function(10)
print(f"Result: {result}")